 source /home_lct/eginer/qp2/quantum_package.rc
 atom=$1
 basis=$2
 mkdir $basis
 cd $basis 
 echo $atom > ${atom}.xyz
 rm -rf $atom.$basis
 qp create_ezfio -b $basis ${atom}.xyz -m 1 -o $atom.$basis
 qp run scf
 # prints out typical values of mu, mu_lda and mu_rsc_lda seem good 
 qp run print_mu_av_tc | tee ${EZFIO_FILE}/mu_av.out
 mu_rsc_lda=` grep "average_mu_rs_c_lda" ${EZFIO_FILE}/mu_av.out | cut -d "=" -f 2`
 qp set ao_two_e_erf_ints mu_erf $mu_rsc_lda 

 qp set tc_h_clean three_body_h_tc true 
 qp set tc_h_clean pure_three_body_h_tc False
 qp set tc_h_clean full_tc_h_solver False
 qp set tc_h_clean comp_left_eigv True

 qp set perturbation pt2_max 0.00001

 qp set tc_h_clean double_normal_ord False #### NORMAL ORDER                                                                                 
 qp set fci_tc cipsi_tc h_tc #### NON HERMITIAN SELECTION : <Chi|H_mu|alpha><alpha|H_mu|Phi>/Delta E 
 qp reset -d 
 qp run fci_tc | tee ${EZFIO_FILE}.fci_tc_tc_h.out

 qp set fci_tc cipsi_tc h_tc_2x2 #### NON HERMITIAN SELECTION
 qp reset -d 
 qp run fci_tc | tee ${EZFIO_FILE}.fci_tc_tc_h_2x2.out

#################### ONLY NEEDS THE RIGHT EIGENVECTOR ###################
 qp set tc_h_clean comp_left_eigv False
 qp set fci_tc cipsi_tc e_sym #### "E_SYM" NON HERMITIAN SELECTION: <Phi|H_mu|alpha><alpha|H_mu|Phi>/Delta E 
 qp reset -d 
 qp run fci_tc | tee ${EZFIO_FILE}.fci_tc_e_sym.out
 
 qp set determinants weight_selection 6 ##### RIGHT COEF SELECTION WITH E_PT2 AS E_SYM
 qp reset -d 
 qp run fci_tc | tee ${EZFIO_FILE}.fci_tc_tc_h_select_coef.out

 qp set fci_tc cipsi_tc reg_h #### USUAL H SELECTION E_PT2 phony
 qp reset -d
 qp run fci_tc | tee ${EZFIO_FILE}.fci_tc_reg_h.out

 qp set fci_tc cipsi_tc sym_h_tc #### (H_mu + H_mu^dagger)/2
 qp reset -d
 qp run fci_tc | tee ${EZFIO_FILE}.fci_tc_sym_h_tc.out

