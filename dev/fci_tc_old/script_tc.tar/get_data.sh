atom=$1
basis=$2
ezfio=${atom}.$basis
cd $basis/

select=tc_h
file=data_${ezfio}.${select}
grep "Ndet, E_tc, E+PT2 =" ${ezfio}.fci_tc_${select}.out > $file
sed -i 's/Ndet, E_tc, E+PT2 = //g' $file

select=tc_h_2x2
file=data_${ezfio}.${select}
grep "Ndet, E_tc, E+PT2 =" ${ezfio}.fci_tc_${select}.out > $file
sed -i 's/Ndet, E_tc, E+PT2 = //g' $file

select=tc_h_select_coef
file=data_${ezfio}.${select}
grep "Ndet, E_tc, E+PT2 =" ${ezfio}.fci_tc_${select}.out > $file
sed -i 's/Ndet, E_tc, E+PT2 = //g' $file

select=e_sym
file=data_${ezfio}.${select}
grep "Ndet, E_tc, E+PT2 =" ${ezfio}.fci_tc_${select}.out > $file
sed -i 's/Ndet, E_tc, E+PT2 = //g' $file

select=reg_h
file=data_${ezfio}.${select}
grep "Ndet, E_tc, E+PT2 =" ${ezfio}.fci_tc_${select}.out > $file
sed -i 's/Ndet, E_tc, E+PT2 = //g' $file

select=sym_h_tc
file=data_${ezfio}.${select}
grep "Ndet, E_tc, E+PT2 =" ${ezfio}.fci_tc_${select}.out > $file
sed -i 's/Ndet, E_tc, E+PT2 = //g' $file

tar -cvf data_${ezfio}.tar data_${ezfio}.* 
